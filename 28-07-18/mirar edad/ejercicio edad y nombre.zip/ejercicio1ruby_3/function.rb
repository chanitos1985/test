Class test
  print "Hola mundo"
end