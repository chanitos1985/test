require './test'
CONSTANT = 1
#a = Saludo.new
#name = gets.chomp
#a.name=name
#age=gets.to_i
#a.age=age
#p a.Hola
a = Saludo.new
puts "ingrese el número de numeros a ingresar"
numeromain=gets.to_i
a.limite = numeromain
p a.Suma
p a.Promedio