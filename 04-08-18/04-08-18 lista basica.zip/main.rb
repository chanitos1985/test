require "./Lista1"
lista = Lista.new
lista.agregarNodo(10)
lista.agregarNodo(20)
lista.agregarNodo(30)
lista.agregarNodo(50)
lista.agregarNodo(90)
lista.imprimirLista
lista.eliminarNodo(20)
p ""
lista.imprimirLista