require "./Nodo"

class Lista
  
  def initialize
    @cabeza = nil
  end

  def agregarNodo(valor)
    if @cabeza
      encuentraUltimo.siguiente = Nodo.new(valor)
    else
      @cabeza = Nodo.new(valor)
    end
  end

  def encuentraUltimo
    nodo = @cabeza
    return nodo if !nodo.siguiente
    return nodo if !nodo.siguiente while (nodo = nodo.siguiente)
  end

  def imprimirLista
    nodo = @cabeza
    while (nodo)
      p nodo.valor
      nodo = nodo.siguiente
    end
  end

  def eliminarNodo(valor)
    if @cabeza.valor == valor
      @cabeza = cabeza.siguiente
      return
    end
    nodo = encuentraAnterior(valor)
    nodo.siguiente = nodo.siguiente.siguiente
  end

  def encuentraAnterior(valor)
    nodo = @cabeza
    return false if !nodo.siguiente
    while nodo
      return nodo if nodo.siguiente and nodo.siguiente.valor == valor
      nodo = nodo.siguiente
    end
  end

  def encontrarNode(valor)
    nodo = @cabeza
    return false if !nodo.siguiente
    while nodo
      return nodo if nodo.valor == valor
      nodo = nodo.siguiente
    end
  end

  def insertarLugar(lugar,valor)
    nodo = @cabeza
    if !nodo
      @cabeza = Nodo.new(valor)
      return
    end
    busqueda = encontrarNode(lugar)
    if busqueda
      siguiente_busq = busqueda.siguiente
      busqueda.siguiente = Nodo.new(valor)
      busqueda.siguiente.siguiente = siguiente_busq
    end
  end

  def insertarPrimero(valor)
    nodo = @cabeza
    @cabeza = Nodo.new(valor)
    if nodo
      @cabeza.siguiente = nodo
    end
  end

end