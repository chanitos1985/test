class Nodo
  attr_accessor :siguiente
  attr_accessor :valor

  def initialize(valor)
    @valor = valor
    @siguiente = nil
  end

  def to_s
    "Valor de nodo:  #{@valor}"
  end
end